package androidx.savedstate;

public final class R {
    private R() {
    }
}

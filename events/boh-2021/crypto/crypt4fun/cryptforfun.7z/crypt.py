import hashlib

inp = input("inp:")
result = ""
c = ""

for e in inp:
	e  = hashlib.md5(e.encode())
	e  = e .hexdigest()
	c +=str(e )
	
for l in c:
	l  = hashlib.sha1(l .encode())
	l  = l .hexdigest()
	result += str(l)
	
f = open('flag.enc','w')
f.write(result)
f.close
	

Sometimes all you need is a little  bit of Javascript

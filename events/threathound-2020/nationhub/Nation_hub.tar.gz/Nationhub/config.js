{

        "token": "Enter Secret token here *_*",
        "prefix": "~",
        "lightNum": "1337",
        "username": "UHJpbWUgOSwgUmVhZCB0aGUgSlMgY2FyZWZ1bGx5",
        "host": "127.0.0.1"

}
